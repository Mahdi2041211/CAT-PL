﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Community
{
    public partial class Post : Form
    {
        public static Post post;
        public Label label;
        public Post()
        {
            InitializeComponent();
            post = this;
            label = Description;
        }
    }
}
