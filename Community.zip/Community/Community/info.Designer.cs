﻿namespace Community
{
    partial class info
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(info));
            this.siticoneBorderlessForm1 = new Siticone.Desktop.UI.WinForms.SiticoneBorderlessForm(this.components);
            this.siticoneVProgressBar3 = new Siticone.Desktop.UI.WinForms.SiticoneVProgressBar();
            this.siticoneVProgressBar2 = new Siticone.Desktop.UI.WinForms.SiticoneVProgressBar();
            this.PostsPanel = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.siticoneVProgressBar1 = new Siticone.Desktop.UI.WinForms.SiticoneVProgressBar();
            this.Name_label = new Siticone.Desktop.UI.WinForms.SiticoneHtmlLabel();
            this.Rename = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Edit_about = new Siticone.Desktop.UI.WinForms.SiticoneCircleButton();
            this.Edit_name = new Siticone.Desktop.UI.WinForms.SiticoneCircleButton();
            this.Photo = new Siticone.Desktop.UI.WinForms.SiticoneCirclePictureBox();
            this.About1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Photo)).BeginInit();
            this.SuspendLayout();
            // 
            // siticoneBorderlessForm1
            // 
            this.siticoneBorderlessForm1.AnimateWindow = true;
            this.siticoneBorderlessForm1.ContainerControl = this;
            this.siticoneBorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.siticoneBorderlessForm1.TransparentWhileDrag = true;
            // 
            // siticoneVProgressBar3
            // 
            this.siticoneVProgressBar3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.siticoneVProgressBar3.Location = new System.Drawing.Point(15, 276);
            this.siticoneVProgressBar3.Name = "siticoneVProgressBar3";
            this.siticoneVProgressBar3.Size = new System.Drawing.Size(385, 2);
            this.siticoneVProgressBar3.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.siticoneVProgressBar3.TabIndex = 37;
            this.siticoneVProgressBar3.Text = "siticoneVProgressBar3";
            this.siticoneVProgressBar3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // siticoneVProgressBar2
            // 
            this.siticoneVProgressBar2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.siticoneVProgressBar2.Location = new System.Drawing.Point(15, 451);
            this.siticoneVProgressBar2.Name = "siticoneVProgressBar2";
            this.siticoneVProgressBar2.Size = new System.Drawing.Size(385, 2);
            this.siticoneVProgressBar2.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.siticoneVProgressBar2.TabIndex = 35;
            this.siticoneVProgressBar2.Text = "siticoneVProgressBar2";
            this.siticoneVProgressBar2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // PostsPanel
            // 
            this.PostsPanel.AutoScroll = true;
            this.PostsPanel.BackColor = System.Drawing.Color.LimeGreen;
            this.PostsPanel.BorderRadius = 30;
            this.PostsPanel.BorderThickness = 1;
            this.PostsPanel.CustomBorderColor = System.Drawing.Color.White;
            this.PostsPanel.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.PostsPanel.FillColor = System.Drawing.Color.White;
            this.PostsPanel.Location = new System.Drawing.Point(15, 459);
            this.PostsPanel.Name = "PostsPanel";
            this.PostsPanel.Size = new System.Drawing.Size(385, 270);
            this.PostsPanel.TabIndex = 32;
            this.PostsPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.PostsPanel_Paint);
            // 
            // siticoneVProgressBar1
            // 
            this.siticoneVProgressBar1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.siticoneVProgressBar1.Location = new System.Drawing.Point(15, 371);
            this.siticoneVProgressBar1.Name = "siticoneVProgressBar1";
            this.siticoneVProgressBar1.Size = new System.Drawing.Size(385, 2);
            this.siticoneVProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.siticoneVProgressBar1.TabIndex = 30;
            this.siticoneVProgressBar1.Text = "siticoneVProgressBar1";
            this.siticoneVProgressBar1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // Name_label
            // 
            this.Name_label.AutoSize = false;
            this.Name_label.AutoSizeHeightOnly = true;
            this.Name_label.BackColor = System.Drawing.Color.Transparent;
            this.Name_label.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F);
            this.Name_label.Location = new System.Drawing.Point(16, 284);
            this.Name_label.Name = "Name_label";
            this.Name_label.Size = new System.Drawing.Size(384, 33);
            this.Name_label.TabIndex = 28;
            this.Name_label.Text = "Ayham";
            // 
            // Rename
            // 
            this.Rename.BorderColor = System.Drawing.Color.OliveDrab;
            this.Rename.BorderRadius = 10;
            this.Rename.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
            this.Rename.BorderThickness = 2;
            this.Rename.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Rename.DefaultText = "";
            this.Rename.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Rename.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Rename.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Rename.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Rename.FillColor = System.Drawing.Color.ForestGreen;
            this.Rename.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rename.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Rename.ForeColor = System.Drawing.Color.Black;
            this.Rename.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rename.Location = new System.Drawing.Point(169, 245);
            this.Rename.Name = "Rename";
            this.Rename.PasswordChar = '\0';
            this.Rename.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Rename.PlaceholderText = "Enter Your Name";
            this.Rename.SelectedText = "";
            this.Rename.Size = new System.Drawing.Size(200, 26);
            this.Rename.TabIndex = 40;
            this.Rename.Visible = false;
            this.Rename.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Rename_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(11, 242);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(11, 338);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 27);
            this.label2.TabIndex = 42;
            this.label2.Text = "About";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(11, 416);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 27);
            this.label3.TabIndex = 43;
            this.label3.Text = "My Posts";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Community.Properties.Resources.edit;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::Community.Properties.Resources.edit;
            this.pictureBox1.Location = new System.Drawing.Point(252, 179);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 36);
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Edit_about
            // 
            this.Edit_about.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Edit_about.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Edit_about.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Edit_about.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Edit_about.FillColor = System.Drawing.Color.Transparent;
            this.Edit_about.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Edit_about.ForeColor = System.Drawing.Color.White;
            this.Edit_about.Image = global::Community.Properties.Resources.edit;
            this.Edit_about.Location = new System.Drawing.Point(375, 340);
            this.Edit_about.Name = "Edit_about";
            this.Edit_about.ShadowDecoration.Mode = Siticone.Desktop.UI.WinForms.Enums.ShadowMode.Circle;
            this.Edit_about.Size = new System.Drawing.Size(25, 25);
            this.Edit_about.TabIndex = 39;
            this.Edit_about.Click += new System.EventHandler(this.Edit_about_Click);
            // 
            // Edit_name
            // 
            this.Edit_name.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Edit_name.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Edit_name.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Edit_name.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Edit_name.FillColor = System.Drawing.Color.Transparent;
            this.Edit_name.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Edit_name.ForeColor = System.Drawing.Color.White;
            this.Edit_name.Image = global::Community.Properties.Resources.edit;
            this.Edit_name.Location = new System.Drawing.Point(375, 244);
            this.Edit_name.Name = "Edit_name";
            this.Edit_name.ShadowDecoration.Mode = Siticone.Desktop.UI.WinForms.Enums.ShadowMode.Circle;
            this.Edit_name.Size = new System.Drawing.Size(25, 25);
            this.Edit_name.TabIndex = 38;
            this.Edit_name.Click += new System.EventHandler(this.Edit_name_Click);
            // 
            // Photo
            // 
            this.Photo.BackColor = System.Drawing.Color.Transparent;
            this.Photo.FillColor = System.Drawing.Color.Transparent;
            this.Photo.Image = ((System.Drawing.Image)(resources.GetObject("Photo.Image")));
            this.Photo.ImageRotate = 0F;
            this.Photo.Location = new System.Drawing.Point(110, 15);
            this.Photo.Name = "Photo";
            this.Photo.ShadowDecoration.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Photo.ShadowDecoration.Depth = 40;
            this.Photo.ShadowDecoration.Enabled = true;
            this.Photo.ShadowDecoration.Mode = Siticone.Desktop.UI.WinForms.Enums.ShadowMode.Circle;
            this.Photo.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(3);
            this.Photo.Size = new System.Drawing.Size(200, 200);
            this.Photo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Photo.TabIndex = 29;
            this.Photo.TabStop = false;
            this.Photo.UseTransparentBackground = true;
            // 
            // About1
            // 
            this.About1.AutoSize = true;
            this.About1.Font = new System.Drawing.Font("Franklin Gothic Demi", 15F);
            this.About1.Location = new System.Drawing.Point(10, 384);
            this.About1.Name = "About1";
            this.About1.Size = new System.Drawing.Size(1340, 32);
            this.About1.TabIndex = 45;
            this.About1.Text = "Something SomethingSomethingSomethingSomethingSomethingSomethingSomethingSomethin" +
    "gSomethingSomething";
            // 
            // info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.LimeGreen;
            this.Controls.Add(this.About1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Rename);
            this.Controls.Add(this.Edit_about);
            this.Controls.Add(this.Edit_name);
            this.Controls.Add(this.siticoneVProgressBar3);
            this.Controls.Add(this.siticoneVProgressBar2);
            this.Controls.Add(this.PostsPanel);
            this.Controls.Add(this.siticoneVProgressBar1);
            this.Controls.Add(this.Photo);
            this.Controls.Add(this.Name_label);
            this.Name = "info";
            this.Size = new System.Drawing.Size(303, 580);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Photo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Siticone.Desktop.UI.WinForms.SiticoneBorderlessForm siticoneBorderlessForm1;
        private Siticone.Desktop.UI.WinForms.SiticoneCircleButton Edit_about;
        private Siticone.Desktop.UI.WinForms.SiticoneCircleButton Edit_name;
        private Siticone.Desktop.UI.WinForms.SiticoneVProgressBar siticoneVProgressBar3;
        private Siticone.Desktop.UI.WinForms.SiticoneVProgressBar siticoneVProgressBar2;
        private Siticone.Desktop.UI.WinForms.SiticonePanel PostsPanel;
        private Siticone.Desktop.UI.WinForms.SiticoneVProgressBar siticoneVProgressBar1;
        private Siticone.Desktop.UI.WinForms.SiticoneCirclePictureBox Photo;
        private Siticone.Desktop.UI.WinForms.SiticoneHtmlLabel Name_label;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox Rename;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label About1;
    }
}
